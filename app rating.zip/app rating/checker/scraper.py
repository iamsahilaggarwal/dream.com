from google_play_scraper import Sort, reviews
from urllib import parse
from nltk.util import pr
from textblob import TextBlob

def check(url):
    app_id = dict(parse.parse_qsl(parse.urlsplit(url).query))['id']
    num = 500
    result, continuation_token = reviews(
        app_id,
        sort=Sort.NEWEST,
        count=num,
    )
    reviews_list, rating_list = [], []
    for i in result:
        reviews_list.append(i['content'])
        rating_list.append(i['score'])

    finReviews=reviews_list #all reviews from scrapper
    finRatings=rating_list #all ratings from scrapper
    totRevCount=len(reviews_list) #total number of reviews

    posRevCount=0
    negRevCount=0
    for i in finReviews:

        i=TextBlob(i)
        pol=i.sentiment.polarity
        if pol>0:
            posRevCount+=1
        else:
            negRevCount+=1

    negratCount = finRatings.count('1')
    negratCount += finRatings.count('2')
    posratCount = finRatings.count('3')
    posratCount += finRatings.count('4')
    posratCount += finRatings.count('5')

    avgposCount=(posratCount+posRevCount)/(totRevCount)
    avgnegCount=(negratCount+negRevCount)/(totRevCount)

    return(avgnegCount,avgposCount,totRevCount)
    #########graph for avgposCount and avgnegCount ##############
