# # from django.test import TestCase

# # Create your tests here.
# # a=int(input(''))

# # b=list(map(int,input().split()))
# b=[1,3,4,-1]

# # c=list(map(int,input().split()))
# c=[1,3,4,1]
# # print(b.count())
# if b.count(-1)==c.count(-1):
#     print('Infinite')
# elif c.count(-1)==2:
#     print(max(0,sum(b)-sum(c)-1))
# elif b.count(-1)==2:
#     print(max(0,sum(c)-sum(b)-1))
# elif b.count(-1) == 1:
#     if sum(b) <= sum(c):
#         print(1)
#     else:
#         print(0)
# else:
#     if sum(c) <= sum(b):
#         print(1)
#     else:
# #         print(0)
# a='hello'
# # print(a[:2])
# l1=[1,2,3]

# l2=[4,5,6]

# print([x*y for x in l1 for y in l2])

# def calculate(n):
#     a=[1,1,1,1]
#     if n==1 or n==2 or n==3 or n==4:
#         print(1)
#     else:
#         for i in range(4,n+1):
#             a.append(a[i-4] +a[i-3]+a[i-2]+a[i-1])
#         print(a[n])

# n=int(input("Enter the value of n : "))
# calculate(n)