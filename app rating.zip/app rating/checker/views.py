from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from nltk.util import pr
from .forms import CreateuserForm
from django.contrib.auth.decorators import login_required

from . import scraper


def home(request):
    return render(request,'index.html')

def register(request):
    form = CreateuserForm()

    if request.method == 'POST':
        form = CreateuserForm(request.POST)
        if form.is_valid():
            form.save()

            return redirect("login")

    context={"form": form}
    return render(request,'register.html',context)

def loginpage(request):

	if request.method == 'POST':
		username = request.POST.get('username')
		password =request.POST.get('password')

		user = authenticate(request, username=username, password=password)

		if user is not None:
			login(request, user)
			return redirect('account')
		else:
			messages.info(request, 'Username OR password is incorrect')

	context = {}
	return render(request,'login.html',context)
	
def logoutUser(request):
	logout(request)
	return redirect('home')

@login_required(login_url='login')
def account(request):
	result={}
	if request.method == 'POST':
		app = request.POST.get('appname')
		url =request.POST.get('appurl')
		
		data=scraper.check(url)
		result["name"] = app
		result["positive"] = data[0]
		result["negitive"] = data[1]
		result["total"] = data[2]

	
	return render(request,'account.html',result)
